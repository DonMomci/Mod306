
Diario di lavoro
##### Nikola Momcilovic
### Canobbio, [16.09.2016]

## Inizio ufficiale progetto.

## Lavori svolti
Nella lezione odierna abbiamo parlato dell'analisi.
Successivamente abbiamo interrogato sul progetto il mandante ottenendo il seguente risultato:

| Domanda                        |       Risposta |
| :-------------                 | :-------- |
| Materiale                      | Compensato, altro materiale da annunciare |
|Dimensione                      |Libera scelta, max 30x30 cm|
|Budget                          | da calcolare|
|Possibilità di capovolgere      | opzionale
|Supporti                        |    opzionali
|Posizione                       |        Nessuna specifica, una per fare i collegamenti
|Uscite Alimentazione/USB        |      Raggiungibili dall'esterno|
|Carica batteria                 |         opzionale
|Colore                          |         indifferente
|Deposito componenti             | opzionale
|Copertura                       | opzionale
|Consegna                        | 21.10.2016|

In base alla tabella soprastante si inizia a documentare il lavoro.
Oggi e nei prossimi giorni:

 - Requisiti
 - Analisi del dominio
 


##  Problemi riscontrati e soluzioni adottate
Come strutturare le domande per l'intervista.
Per prepararle abbiamo collaborato tutti.

##  Punto della situazione rispetto alla pianificazione
Nessuna pianificazione specifica è stata ancora impostata.


## Programma di massima per la prossima giornata di lavoro
Sta ai docenti scegliere.
