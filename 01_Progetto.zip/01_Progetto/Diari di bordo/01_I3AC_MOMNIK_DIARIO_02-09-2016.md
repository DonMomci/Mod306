

Diario di lavoro - 02.09.2016
##### Nikola Momcilovic
### Canobbio, [DATE]

##Caro diario di bordo, questo è il primo giorno, e:

## Lavori svolti
Ho ascoltato l'introduzione alla materia, spiegazione sulla valutazione sulle skills finali che si otterranno alla fine del modulo (se si lavora).
Nella seconda parte della lezione, tre punti da 45min, sono diventati tre punti da 45min L'UNO. Tutto cio, come si puo ben immaginare è a causa del proxy.
Questo amicone di tutti, "proxy", impediva di collegarsi all'account gitHub tramite l'ausilio di SourceTree.
Alla fine ci è stato compito di scrivere il diario di lavoro.

##  Problemi riscontrati e soluzioni adottate
Proxy impediva di accedere tramite l'ausilio di SourceTree al nostro account gitHub.
Configurare un file di nome .gitconfig e configurarlo come nella guida presente nel account gitHub "lumug" al percorso /iSete/ambiente di sviluppo.md

##  Punto della situazione rispetto alla pianificazione
Nessuna pianificazione specifica è stata ancora impostata.


## Programma di massima per la prossima giornata di lavoro
Sta ai docenti scegliere.