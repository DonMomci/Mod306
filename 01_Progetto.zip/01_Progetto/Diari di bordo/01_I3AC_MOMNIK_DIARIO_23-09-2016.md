
Diario di lavoro
##### Nikola Momcilovic
### Canobbio, [23.09.2016]

## Teoria use-case.

## Lavori svolti
Fatto un test per le prime due ore.
Successivamente la teoria sugli use-case.
In conclusione, per ben tre ore, abbiamo risolto un esercizio nel quale bisognava fare l'use-case di un problema per un garage di veicoli.

##  Problemi riscontrati e soluzioni adottate
L'unico problema che si è presentato è risolvere l'use-case dell'esercizio.
Per risolverlo hanno dovuto farlo i docenti.

##  Punto della situazione rispetto alla pianificazione
Nessuna pianificazione specifica è stata ancora impostata.


## Programma di massima per la prossima giornata di lavoro
Sta ai docenti scegliere.
