1. [Introduzione](#introduzione)

  - [Informazioni sul progetto](#informazioni-sul-progetto)

  - [Abstract](#abstract)

  - [Scopo](#scopo)

1. [Analisi](#analisi)

  - [Analisi del dominio](#analisi-del-dominio)

  - [Analisi e specifica dei requisiti](#analisi-e-specifica-dei-requisiti)

1. [Use case](#use-case)

  - [Pianificazione](#pianificazione)

  - [Analisi dei mezzi](#analisi-dei-mezzi)

1. [Progettazione](#progettazione)

  - [Design dell’architettura del sistema](#design-dell’architettura-del-sistema)

  - [Design dei dati e database](#design-dei-dati-e-database)



## Introduzione

### Informazioni sul progetto

  In questo capitolo raccogliere le informazioni relative al progetto, ad esempio:

  -   Nikola Momcilovic
    - Ruolo : Project Manager
    - Scuola : SAMT
    - Sezione : Informatica
    - Materia : Modulo 306


  -  Massimo Sartori e Francesco Mussi
      - Ruolo : Mandanti
      - Scuola : SAMT
      - Sezione : Informatica
      - Materia : Modulo 306


  - Inizio 16.09.2016
  - Consegna 21.10.2016


### Abstract

  E’ una breve e accurata rappresentazione dei contenuti di un documento,
  senza notazioni critiche o valutazioni. Lo scopo di un abstract efficace
  dovrebbe essere quello di far conoscere all’utente il contenuto di base
  di un documento e metterlo nella condizione di decidere se risponde ai
  suoi interessi e se è opportuno il ricorso al documento originale.

  Può contenere alcuni o tutti gli elementi seguenti:

  -   **Background/Situazione iniziale**

  -   **Descrizione del problema e motivazione**: Che problema ho cercato
      di risolvere? Questa sezione dovrebbe includere l'importanza del
      vostro lavoro, la difficoltà dell'area e l'effetto che potrebbe
      avere se portato a termine con successo.

  -   **Approccio/Metodi**: Come ho ottenuto dei progressi? Come ho
      risolto il problema (tecniche…)? Quale è stata l’entità del mio
      lavoro? Che fattori importanti controllo, ignoro o misuro?

  -   **Risultati**: Quale è la risposta? Quali sono i risultati? Quanto è
      più veloce, più sicuro, più economico o in qualche altro aspetto
      migliore di altri prodotti/soluzioni?

  Esempio di abstract:

  > *As the size and complexity of today’s most modern computer chips
  > increase, new techniques must be developed to effectively design and
  > create Very Large Scale Integration chips quickly. For this project, a
  > new type of hardware compiler is created. This hardware compiler will
  > read a C++ program, and physically design a suitable microprocessor
  > intended for running that specific program. With this new and powerful
  > compiler, it is possible to design anything from a small adder, to a
  > microprocessor with millions of transistors. Designing new computer
  > chips, such as the Pentium 4, can require dozens of engineers and
  > months of time. With the help of this compiler, a single person could
  > design such a large-scale microprocessor in just weeks.*

### Scopo

  Lo scopo del progetto è puramente didattico.

  Il mandante ha richiesto un holder per un arduino.
  Esso ha come scopo di fare da superficie di lavoro per l'arduino e una breadboard (modelli definiti) fissi per effettuare collegamenti e trasporti.


## Analisi

### Analisi del dominio

  Il progetto consiste nel permettere agli allievi del secondo anno della sezione d'informatica di adoperarlo per le lezioni del modulo 121. Questo modulo è principalmente concentrato nella programmazione lato arduino nella quale dovranno essere eseguiti dei collegamenti tra l'arduino e la breadboard.
  Attualmente esistono gia degli holder. Essi sono strutturati come nell'immagine seguente per appoggiare l'arduino e l'holder in modo che non si spostino e si possano fare i collegamenti tra di essi:


![Holder arduino](img\dominio_holder.jpg)
&copy; Google Image.

### Analisi e specifica dei requisiti


Tratto dal quaderno dei compiti fornito dal mandante:
>L’obiettivo principale di questo progetto è quello di realizzare una base di supporto o un case per l’Arduino.

>La base di supporto deve servire per alloggiare al suo interno sia l’Arduino che la breadboard (quella contenuta all’interno del tuo kit).  Lo scopo è quello di realizzare un supporto che permetta di lavorare con i due elementi senza rischiare di compromettere i cablaggi di un possibile prototipo, dando così la possibilità di spostare, con più sicurezza, il montaggio in diversi ambienti.

Dal QdC (Quaderno dei Compiti ) si è tenuto un colloquio con il mandate, alla quale si sono poste delle domande:

| Domanda                        |       Risposta |
| :-------------                 | :-------- |
| Materiale                      | Compensato, altro materiale da annunciare |
|Dimensione                      |Libera scelta, max 30x30 cm|
|Budget                          | da calcolare|
|Possibilità di capovolgere      | opzionale
|Supporti                        |    opzionali
|Posizione                       |        Nessuna specifica, una per fare i collegamenti
|Uscite Alimentazione/USB        |      Raggiungibili dall'esterno|
|Carica batteria                 |         opzionale
|Colore                          |         indifferente
|Deposito componenti             | da fare
|Copertura                       | opzionale
|Consegna                        | 21.10.2016|

Dalla seguente tabella si è passati a redigere i requisiti.

#### Requisiti

|ID  |REQ-001                                       |
|----|------------------------------------------------|
|**Nome**    |Holder per arduino e breadboard|
|**Priorità**|1                     |
|**Versione**|1.0                   |
|**Note**    ||
|            |**Sotto requisiti** |
|**001**      | Il mandante necessita di avere un holder per lavorare in piena libertà con l'arduino e la breadboard |

  |ID  |REQ-002                                        |
  |----|------------------------------------------------|
  |**Nome**    |Materiale |
  |**Priorità**|1                     |
  |**Versione**|1.0                   |
  |**Note**    ||
  |            |**Sotto requisiti** |
  |**001**      | Il mandante necessita di avere la base dell'holder in compensato |


  |ID  |REQ-003                                      |
  |----|------------------------------------------------|
  |**Nome**    |Dimensioni |
  |**Priorità**|2                   |
  |**Versione**|1.0                   |
  |**Note**    ||
  |            |**Sotto requisiti** |
  |**001**      | Il mandante necessita le dimensioni che siano di massimo 30x30 cm  |
  |**002**      | Spessore di 8 mm  |

  |ID  |REQ-004                                       |
    |----|------------------------------------------------|
    |**Nome**    | Collegamenti dall'arduino
    |**Priorità**|2                   |
    |**Versione**|1.0                   |
    |**Note**    ||
    |            |**Sotto requisiti** |
    |**001**      | Accessibile entrata alimentazione e collegamento (USB)  |
    |**002**      | Accessibili i pin  |

  |ID  |REQ-005                                        |
    |----|------------------------------------------------|
    |**Nome**    |Deposito componenti |
    |**Priorità**|1                     |
    |**Versione**|1.0                   |
    |**Note**    ||
    |            |**Sotto requisiti** |
    |**001**      | Il mandante necessita di avere un luogo dove depositare i componenti|




### Pianificazione


Prima di stabilire una pianificazione bisogna avere almeno una vaga idea
del modello di sviluppo che si intende adottare. In questa sezione
bisognerà inserire il modello concettuale di sviluppo che si seguirà
durante il progetto. Gli elementi di riferimento per una buona
pianificazione derivano da una scomposizione top-down della problematica
del progetto.

La pianificazione può essere rappresentata mediante un diagramma di
Gantt.

Se si usano altri metodi di pianificazione (es scrum), dovranno apparire
in questo capitolo.

### Analisi dei mezzi

Elencare e *descrivere* i mezzi disponibili per la realizzazione del
progetto. Ricordarsi di sempre descrivere nel dettaglio le versioni e il
modello di riferimento.

SDK, librerie, tools utilizzati per la realizzazione del progetto e
eventuali dipendenze.

Su quale piattaforma dovrà essere eseguito il prodotto? Che hardware
particolare è coinvolto nel progetto? Che particolarità e limitazioni
presenta? Che hw sarà disponibile durante lo sviluppo?

## Progettazione

Questo capitolo descrive esaustivamente come deve essere realizzato il
prodotto fin nei suoi dettagli. Una buona progettazione permette
all’esecutore di evitare fraintendimenti e imprecisioni
nell’implementazione del prodotto.

### Design dell’architettura del sistema

Descrive:

-   La struttura del programma/sistema lo schema di rete...

-   Gli oggetti/moduli/componenti che lo compongono.

-   I flussi di informazione in ingresso ed in uscita e le
    relative elaborazioni. Può utilizzare *diagrammi di flusso dei
    dati* (DFD).

-   Eventuale sitemap

### Design dei dati e database

Descrizione delle strutture di dati utilizzate dal programma in base
agli attributi e le relazioni degli oggetti in uso.

### Schema E-R, schema logico e descrizione.

Se il diagramma E-R viene modificato, sulla doc dovrà apparire l’ultima
versione, mentre le vecchie saranno sui diari.

### Design delle interfacce

Descrizione delle interfacce interne ed esterne del sistema e
dell’interfaccia utente. La progettazione delle interfacce è basata
sulle informazioni ricavate durante la fase di analisi e realizzata
tramite mockups.

### Design procedurale

Descrive i concetti dettagliati dell’architettura/sviluppo utilizzando
ad esempio:

-   Diagrammi di flusso e Nassi.

-   Tabelle.

-   Classi e metodi.

-   Tabelle di routing

-   Diritti di accesso a condivisioni …

Questi documenti permetteranno di rappresentare i dettagli procedurali
per la realizzazione del prodotto.
