

Diario di lavoro - 09.09.2016
##### Nikola Momcilovic
### Canobbio, [DATE]


## Lavori svolti
Durante la lezione odierna abbiamo avuto informazioni generali riguradante i progetti di 3a e di 4a e imparato come strutturarli.
Abbiamo visto in specifico:
- La struttura di un documento per un progetto.
- Le varie fasi di un progetto e come farle.
- Il ciclo di vita di un progetto.

Ci siamo divisi nei due gruppi , gruppo progetto "case" e gruppo progetto "holder case".

Inoltre alla fine della lezione abbiamo collaborato tra i due gruppi per generare le domande da fare nell'intervista.


##  Problemi riscontrati e soluzioni adottate
Come strutturare le domande per l'intervista.
Per prepararle abbiamo collaborato tutti.

##  Punto della situazione rispetto alla pianificazione
Nessuna pianificazione specifica è stata ancora impostata.


## Programma di massima per la prossima giornata di lavoro
Sta ai docenti scegliere.