
Diario di lavoro
##### Nikola Momcilovic
### Canobbio, [23.09.2016]

## Progettazione e Pianificazione.

## Lavori svolti
Fatta la teoria sulla pianificazione e sulla progettazione.
Inizio della documentazione, finire il gantt e il risultato astratto del progetto.

##  Problemi riscontrati e soluzioni adottate
Trovare un software per il gantt e per il risultato astratto del progetto.
Per il gantt utilizzato tom's planner mentre per il progetto astratto skatchup.

##  Punto della situazione rispetto alla pianificazione
Da finire il gantt e lista del materiale da utilizzare.


## Programma di massima per la prossima giornata di lavoro
Sta ai docenti scegliere.
