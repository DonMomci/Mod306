
Diario di lavoro
##### Nikola Momcilovic
### Canobbio, [07.09.2016]

## Integrazione, implementazione e test.

## Lavori svolti
Fatta la teoria su Integrazione, implementazione e test.
il 04.10 ho spedito la lista del materiale:

| Materiale | Misure |
| :------------- | :------------- |
| Compensato    | 25cm x 20cm x 8mm      |
| Velcro     | 20 x 20 cm      |
| Polistirolo       | 20 x 5 x 2cm      |
| Colla per polistirolo      | -       |



##  Problemi riscontrati e soluzioni adottate
Solamente la colla risulta essere corretta.

Compensato : 6mm, non è un problema poichè è ugualmente resistente.

Polistirolo: non è stato trovato.

Velcro: è stato consegnato un 10x10cm da dividere in 4!

Sull'ultimo risulta essere un problema poichè il progetto si basa unicamente su di esso.
Il signor Barchi giustamente mi ha chiesto di adattarmi poichè il costo del velcro è abbastanza eccessivo. Dopo di che mi sono consulato con il mandante il quale mi ha detto che in base al mio progetto esso è fondamentale dunque di ricordare per email.

##  Punto della situazione rispetto alla pianificazione
Tutto in regola.


## Programma di massima per la prossima giornata di lavoro
Terminare il progetto ed effettuare i test.
